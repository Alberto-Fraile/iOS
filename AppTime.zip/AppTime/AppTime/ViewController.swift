//
//  ViewController.swift
//  AppTime
//
//  Created by APPS2T on 29/10/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var viewBackground: UIView!
    @IBOutlet var changeImage: UIImageView!
    @IBOutlet weak var ButtonTapped: UIButton!
    
    var pulsar = true
    let imagenArray = ["moon.stars.fill", "cloud.sun.fill"]
    
    lazy var gradient: CAGradientLayer = {
        let gradient = CAGradientLayer()
        gradient.type = .axial
        gradient.colors = [
            UIColor.blue.cgColor,
            UIColor.cyan.cgColor,
            UIColor.white.cgColor
        ]
        gradient.locations = [0, 1, 28]
        return gradient
    }()
    
    lazy var darkGradient: CAGradientLayer = {
        let darkGradient = CAGradientLayer()
        darkGradient.type = .axial
        darkGradient.colors = [
            UIColor.black.cgColor,
            UIColor.darkGray.cgColor,
            
        ]
        darkGradient.locations = [0, 1, 28]
        return darkGradient
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ButtonTapped.layer.cornerRadius = 18
        gradient.frame = view.viewWithTag(23)!.bounds
        view.viewWithTag(23)!.layer.addSublayer(gradient)
    }

    @IBAction func buttonTapped(_ sender: UIButton) {
        if pulsar == true {
            pulsar = false
            _ = darkGradient.frame = view.viewWithTag(23)!.bounds
            view.viewWithTag(23)!.layer.addSublayer(darkGradient)
            changeImage.image = UIImage(named: imagenArray[0])
        }else{
            pulsar = true
            gradient.frame = view.viewWithTag(23)!.bounds
            view.viewWithTag(23)!.layer.addSublayer(gradient)
            changeImage.image = UIImage(named: imagenArray[1])
        }
    }
}

