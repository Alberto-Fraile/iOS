//
//  ViewController.swift
//  Frameworks
//
//  Created by Alaberto Fraile on 22/11/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        if section == 0 { return MockData.frameworks.count}
        else {return MockData.frameworks.count}
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "FrameworkCellid", for: indexPath) as? FrameworkCell{
            if indexPath.section == 0 {
                cell.framework = MockData.frameworks[indexPath.row]
            }
            else if indexPath.section == 1{
                cell.framework = MockData.frameworks[indexPath.row]
            }
            return cell
        } else {
            return UITableViewCell()
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if let detailControl = storyboard?.instantiateViewController(identifier: "DetailID") as? FrameworkDetail {
            detailControl.framework = MockData.frameworks[indexPath.row]
            navigationController?.pushViewController(detailControl, animated: true)
        }
    }
}

