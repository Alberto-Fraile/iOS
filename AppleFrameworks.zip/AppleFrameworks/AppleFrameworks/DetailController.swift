//
//  DetailController.swift
//  AppleFrameworks
//
//  Created by APPS2T on 23/11/21.
//

import UIKit
import SafariServices

class FrameworkDetail: UIViewController {
    
    
    var framework: Framework?
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var descriptionTextView: UITextView!
    @IBOutlet var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        renderUI()
        button.layer.cornerRadius = 6
    }
    
    private func renderUI() {
        guard let framework = framework else { return }
        
        nameLabel.text = framework.name
        imageView.image = UIImage (named: framework.imageName)
        descriptionTextView?.text = framework.description
    }
    
    
    @IBAction func safariButton(_sender: Any) {
        if let url = URL(string: framework?.urlString ?? ""){
            let safari = SFSafariViewController(url: url)
            safari.modalPresentationStyle = .automatic
            present(safari, animated: true, completion: nil)
        }
    }
}
