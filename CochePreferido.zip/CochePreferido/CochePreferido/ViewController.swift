//
//  ViewController.swift
//  CochePreferido
//
//  Created by APPS2T on 21/10/21.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet var optionsPicker: UIPickerView!
    @IBOutlet var selectionLabel: UILabel!
    @IBOutlet var imageChange: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        optionsPicker.dataSource = self
        optionsPicker.delegate = self
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return marca.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return marca[row].marca
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        imageChange.image = UIImage (named: marca[row].logo)
        selectionLabel.text = "Has seleccionado \(marca[row].marca)"
    }

}

