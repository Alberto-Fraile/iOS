//
//  Marca.swift
//  CochePreferido
//
//  Created by APPS2T on 21/10/21.
//

import Foundation
struct Marca {
    var marca: String
    var logo: String
}
let marca = [Marca(marca: "Mercedes", logo: "Mercedes"),
             Marca(marca: "Bentley", logo: "Bentley"),
             Marca(marca: "Maserati", logo: "Maserati"),
             Marca(marca: "Jaguar", logo: "Jaguar"),
             Marca(marca: "Seat", logo: "Seat")]

